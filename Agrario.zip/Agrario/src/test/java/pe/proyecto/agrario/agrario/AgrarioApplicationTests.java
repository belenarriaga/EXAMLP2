package pe.proyecto.agrario.agrario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgrarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
