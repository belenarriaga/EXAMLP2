package pe.proyecto.agrario.agrario.repository;


import pe.proyecto.agrario.agrario.modelo.Expediente;

public interface IExpedienteRepository extends ICrudGenericRepository<Expediente,Long> {
}
