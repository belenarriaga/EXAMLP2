package pe.proyecto.agrario.agrario.service;


import pe.proyecto.agrario.agrario.modelo.Cliente;

public interface IClienteService extends ICrudGenericService<Cliente,Long> {
}
