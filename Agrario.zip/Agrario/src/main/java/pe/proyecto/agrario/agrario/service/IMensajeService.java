package pe.proyecto.agrario.agrario.service;


import pe.proyecto.agrario.agrario.modelo.Mensaje;

public interface IMensajeService extends ICrudGenericService<Mensaje,Long> {
}
