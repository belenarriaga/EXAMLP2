package pe.proyecto.agrario.agrario.repository;


import pe.proyecto.agrario.agrario.modelo.Mensaje;

public interface IMensajeRepository extends ICrudGenericRepository<Mensaje,Long> {
}
