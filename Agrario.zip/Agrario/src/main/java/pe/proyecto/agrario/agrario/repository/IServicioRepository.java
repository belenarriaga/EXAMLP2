package pe.proyecto.agrario.agrario.repository;


import pe.proyecto.agrario.agrario.modelo.Servicio;

public interface IServicioRepository extends ICrudGenericRepository<Servicio,Long> {
}
