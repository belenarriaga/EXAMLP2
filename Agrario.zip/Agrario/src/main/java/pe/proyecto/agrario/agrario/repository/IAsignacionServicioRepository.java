package pe.proyecto.agrario.agrario.repository;

import pe.proyecto.agrario.agrario.modelo.AsignacionServicio;

public interface IAsignacionServicioRepository  extends ICrudGenericRepository<AsignacionServicio,Long>{
}
