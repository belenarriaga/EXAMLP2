package pe.proyecto.agrario.agrario.service;


import pe.proyecto.agrario.agrario.modelo.Cita;

public interface ICitaService extends ICrudGenericService<Cita,Long> {
}
