package pe.proyecto.agrario.agrario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgrarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgrarioApplication.class, args);
	}

}
