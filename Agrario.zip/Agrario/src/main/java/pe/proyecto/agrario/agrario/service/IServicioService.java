package pe.proyecto.agrario.agrario.service;


import pe.proyecto.agrario.agrario.modelo.Servicio;

public interface IServicioService  extends ICrudGenericService<Servicio,Long>{
}
