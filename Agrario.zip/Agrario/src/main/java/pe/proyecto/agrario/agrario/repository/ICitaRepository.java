package pe.proyecto.agrario.agrario.repository;


import pe.proyecto.agrario.agrario.modelo.Cita;

public interface ICitaRepository extends ICrudGenericRepository<Cita,Long> {
}
