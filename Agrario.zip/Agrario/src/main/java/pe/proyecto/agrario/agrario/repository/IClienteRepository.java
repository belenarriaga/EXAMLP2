package pe.proyecto.agrario.agrario.repository;


import pe.proyecto.agrario.agrario.modelo.Cliente;

public interface IClienteRepository extends ICrudGenericRepository<Cliente,Long>{
}
