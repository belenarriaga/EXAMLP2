package pe.proyecto.agrario.agrario.service;


import pe.proyecto.agrario.agrario.modelo.Usuario;

public interface IUsuarioService  extends ICrudGenericService<Usuario,Long>{
}
