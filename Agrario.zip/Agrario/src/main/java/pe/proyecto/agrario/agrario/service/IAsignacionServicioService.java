package pe.proyecto.agrario.agrario.service;

import pe.proyecto.agrario.agrario.modelo.AsignacionServicio;

public interface IAsignacionServicioService extends ICrudGenericService<AsignacionServicio,Long> {
}
