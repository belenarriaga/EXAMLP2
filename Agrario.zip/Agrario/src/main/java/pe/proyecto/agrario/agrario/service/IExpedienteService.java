package pe.proyecto.agrario.agrario.service;


import pe.proyecto.agrario.agrario.modelo.Expediente;

public interface IExpedienteService  extends ICrudGenericService<Expediente,Long>{
}
