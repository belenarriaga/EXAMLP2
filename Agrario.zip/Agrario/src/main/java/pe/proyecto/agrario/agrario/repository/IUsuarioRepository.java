package pe.proyecto.agrario.agrario.repository;


import pe.proyecto.agrario.agrario.modelo.Usuario;

public interface IUsuarioRepository extends ICrudGenericRepository<Usuario,Long>{
}
