package pe.proyecto.agrario.agrario.repository;


import pe.proyecto.agrario.agrario.modelo.Recordatorio;

public interface IRecordatorioRepository extends ICrudGenericRepository<Recordatorio,Long>{
}
